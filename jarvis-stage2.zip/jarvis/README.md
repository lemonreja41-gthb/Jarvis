# JARVIS - Stage 2 (minimal shell)
1. Open this folder in Android Studio (current stable). Accept the AGP/Gradle upgrade prompt if shown; Studio generates the Gradle wrapper.
2. Sync, then Run on a device/emulator (API 26+).
3. Unit test: ./gradlew :app:testDebugUnitTest
Status: NOT yet compiled by the author. Report any build errors back for Stage 2 fixes.
