package com.jarvis.assistant

import com.jarvis.assistant.ui.Destination
import org.junit.Assert.assertEquals
import org.junit.Test

class DestinationTest {
    @Test
    fun navigationHasFourTopLevelDestinations() {
        assertEquals(4, Destination.entries.size)
    }
}
